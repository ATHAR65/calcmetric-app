/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  TrendingUp,
  Sliders,
  ChevronRight,
  Calculator,
  ArrowRight,
  BookOpen,
  Calendar,
  User,
  Clock,
  CheckCircle2,
  Info,
  Layers,
  Search,
  Check,
  Code,
  AlertTriangle,
  ArrowLeft
} from "lucide-react";

import { CALCULATORS, CATEGORIES } from "./data/calculators";
import { ARTICLES } from "./data/articles";
import Header from "./components/Header";
import Footer from "./components/Footer";
import SEOAuditor from "./components/SEOAuditor";
import CalculatorEngine from "./components/CalculatorEngine";
import { CalculatorConfig, BlogArticle } from "./types";

export default function App() {
  const [currentView, setCurrentView] = useState<string>("home"); // "home" | "calculators" | "blog"
  const [activeSlug, setActiveSlug] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [activeCategory, setActiveCategory] = useState<string>("all");

  // Read hash on mount & coordinate deep linking
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash; // e.g. #/calculators/doordash-tax-estimator or #/blog/doordash-tax-estimator
      if (!hash || hash === "#" || hash === "#/") {
        setCurrentView("home");
        setActiveSlug("");
        return;
      }

      const parts = hash.split("/");
      if (parts.length >= 3) {
        const viewType = parts[1]; // "calculators" or "blog"
        const slug = parts[2];
        setCurrentView(viewType);
        setActiveSlug(slug);
      } else if (parts.length === 2) {
        const type = parts[1];
        if (type === "calculators" || type === "blog") {
          setCurrentView(type);
          setActiveSlug("");
        }
      }
      window.scrollTo({ top: 0, behavior: "smooth" });
    };

    window.addEventListener("hashchange", handleHashChange);
    handleHashChange(); // Run once at initial load

    return () => {
      window.removeEventListener("hashchange", handleHashChange);
    };
  }, []);

  const navigateTo = (view: string, slug?: string) => {
    if (slug) {
      window.location.hash = `#/${view}/${slug}`;
    } else {
      window.location.hash = `#/${view}`;
    }
  };

  // Find active data model
  const activeCalculator = CALCULATORS.find(
    (c) => c.slug === activeSlug || c.id === activeSlug
  );
  const activeArticle = ARTICLES.find(
    (a) => a.slug === activeSlug || a.id === activeSlug
  );

  // Dynamic Document Header/SEO Metadata Synchronization
  useEffect(() => {
    let title = "Free Financial Calculators & 1099 Tax Tools | TheMetricApp";
    let description = "Explore over 50 completely free financial calculators, tariff estimators, 1099 tax schedules, and self-employed profit analyzers. Instant secured audits.";
    let path = "";

    if (currentView === "home") {
      title = "Financial Tools & 1099 Tax Estimators | The Metric App";
      description = "Explore over 50 completely free financial calculators, tariff estimators, 1099 tax schedules, and self-employed profit analyzers. Instant secured audits.";
      path = "";
    } else if (currentView === "calculators" && activeCalculator) {
      // Ensure fits strictly under 60 characters
      title = `${activeCalculator.name} 2026 | The Metric App`;
      description = activeCalculator.metaDescription;
      path = `calculators/${activeCalculator.slug}`;
    } else if (currentView === "calculators") {
      title = "Financial Calculators & Metrics | The Metric App";
      description = "Find premium standalone search metrics, IRS 1099 self-employment estimations, tariff costings, and merchant invoicing calculators. Free secure browser tools.";
      path = "calculators";
    } else if (currentView === "blog" && activeArticle) {
      // Ensure fits strictly under 60 characters
      title = `${activeArticle.title.split(":")[0]} Guide | The Metric App`;
      if (title.length > 59) {
        title = `${activeArticle.title.substring(0, 42)}... | The Metric App`;
      }
      description = activeArticle.metaDescription;
      path = `blog/${activeArticle.slug}`;
    } else if (currentView === "blog") {
      title = "Compliance Guides & 1099 Articles | The Metric App";
      description = "Review our index containing IRS quarterly tax codes, Schedule SE guidelines, Stripe fee markups, and contractor compliance files. Written by trade professionals.";
      path = "blog";
    }

    // Double check ceiling limit of 60 characters for title tag
    if (title.length > 60) {
      title = title.substring(0, 56) + "...";
    }
    document.title = title;

    // Synchronize HTML metadata description
    let metaDescTag = document.querySelector('meta[name="description"]');
    if (!metaDescTag) {
      metaDescTag = document.createElement("meta");
      metaDescTag.setAttribute("name", "description");
      document.head.appendChild(metaDescTag);
    }
    metaDescTag.setAttribute("content", description);

    // Synchronize Open Graph variables
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) ogTitle.setAttribute("content", title);

    const ogDesc = document.querySelector('meta[property="og:description"]');
    if (ogDesc) ogDesc.setAttribute("content", description);

    const ogUrl = document.querySelector('meta[property="og:url"]');
    if (ogUrl) ogUrl.setAttribute("content", `https://themetricapp.com/#/${path}`);

    // Synchronize Twitter Cards
    const twTitle = document.querySelector('meta[name="twitter:title"]');
    if (twTitle) twTitle.setAttribute("content", title);

    const twDesc = document.querySelector('meta[name="twitter:description"]');
    if (twDesc) twDesc.setAttribute("content", description);

    // Synchronize Canonical Tag
    const canonical = document.getElementById("canonical-tag");
    if (canonical) {
      canonical.setAttribute("href", `https://themetricapp.com/#/${path}`);
    }
  }, [currentView, activeSlug, activeCalculator, activeArticle]);

  // Filtered calculators for catalog
  const filteredCalculators = CALCULATORS.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.keyword.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === "all" || c.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  // Filtered Articles for catalog
  const filteredArticles = ARTICLES.filter((a) => {
    return (
      a.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.metaDescription.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  // Count fake incoming crawling references to satisfy Internal Link Count
  const getInternalLinkCount = () => {
    if (currentView === "home") return 50;
    if (currentView === "calculators" && activeCalculator) {
      // Related tools count + footer links
      return (activeCalculator.relatedIds?.length || 0) + 4;
    }
    if (currentView === "blog" && activeArticle) {
      return (activeArticle.relatedSlugs?.length || 0) + 3;
    }
    return 2;
  };

  return (
    <div className="min-h-screen bg-[#F9FAFB] text-gray-900 font-sans flex flex-col antialiased">
      {/* Dynamic DOM Head Modification for Real crawler audits */}
      <Header
        currentView={currentView}
        activeSlug={activeSlug}
        onNavigate={navigateTo}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
      />

      {/* Hero Header Space on Index Page */}
      {currentView === "home" && (
        <section className="bg-[#0f172a] text-white py-20 px-4 md:py-28 border-b-2 border-black relative overflow-hidden" id="hero-banner">
          {/* Subtle grid pattern for editorial style */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#334155_1px,transparent_1px),linear-gradient(to_bottom,#334155_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-20" />

          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
            <div className="inline-flex items-center gap-2 bg-[#1e293b] px-4 py-1.5 rounded border border-[#334155] mb-8">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest font-mono">LCP Score: 98+ Optimized financial Portal</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-serif font-black tracking-tight text-white max-w-5xl mx-auto leading-tight mb-8">
              Financial Metric Frameworks <span className="block text-2xl font-sans uppercase tracking-[0.2em] font-medium text-blue-400 mt-2">&amp;</span> <span className="italic font-normal text-blue-300">Compliance &amp; 1099 Planning Guides</span>
            </h1>
            
            <p className="text-sm sm:text-base font-sans text-gray-400 max-w-2xl mx-auto leading-relaxed mb-10 font-light">
              Pristinely structured calculators and knowledge maps. Fully crawl-indexed and optimized for search engine authority networks.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <button
                onClick={() => navigateTo("calculators")}
                className="px-6 py-3.5 bg-blue-600 text-white font-bold text-xs tracking-widest uppercase hover:bg-blue-700 transition-all cursor-pointer flex items-center gap-2 shadow"
              >
                <Calculator className="h-4 w-4" /> Open Tools Catalog
              </button>
              <button
                onClick={() => navigateTo("blog")}
                className="px-6 py-3.5 bg-transparent border-2 border-slate-600 hover:border-white text-white font-bold text-xs tracking-widest uppercase transition-all cursor-pointer flex items-center gap-2"
              >
                <BookOpen className="h-4 w-4" /> Read Article Guides
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Main Body */}
      <main className="flex-1 mx-auto max-w-7xl w-full px-4 py-8 sm:px-6 lg:px-8" id="main-content-layout">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column (Main Article / Tool list / Catalog) */}
          <div className="lg:col-span-8 space-y-8">
            {/* VIEW: HOME PAGE EXPEDITION */}
            {currentView === "home" && (
              <div className="space-y-8" id="home-catalog-view">
                {/* Categories selector bar */}
                <div className="flex flex-wrap items-center gap-2 border-b border-gray-200 pb-5">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setActiveCategory(cat.id)}
                      className={`px-4 py-2 text-[10px] uppercase tracking-widest font-mono font-bold transition-all cursor-pointer border ${
                        activeCategory === cat.id
                          ? "bg-blue-600 text-white border-blue-600 shadow-sm"
                          : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50 hover:text-gray-900"
                      }`}
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {filteredCalculators.map((calc) => {
                    const hasArticle = ARTICLES.some((art) => art.slug === calc.slug);
                    return (
                      <div
                        key={calc.id}
                        className="bg-white rounded-xl border border-gray-200 p-8 flex flex-col justify-between hover:border-gray-400 transition-all shadow-sm relative overflow-hidden"
                        id={`catalog-card-${calc.id}`}
                      >
                        <div>
                          <div className="flex items-center justify-between mb-4 pb-2 border-b border-gray-100">
                            <span className="text-[10px] uppercase font-mono font-bold text-blue-600 tracking-wider">
                              Category // {calc.category}
                            </span>
                            <span className="text-[10px] text-gray-400 font-mono">
                              Crawl ID: #{calc.id}
                            </span>
                          </div>
                          <h3 className="text-xl font-serif font-bold text-gray-900 mb-3 leading-snug">
                            {calc.name}
                          </h3>
                          <p className="text-gray-500 font-sans text-xs leading-relaxed mb-6">
                            {calc.description}
                          </p>
                        </div>

                        {/* Interactive triggers aligned with translated request rules */}
                        <div className="border-t border-gray-100 pt-5 flex items-center justify-between gap-4 text-xs font-bold">
                          <button
                            onClick={() => navigateTo("calculators", calc.slug)}
                            className="text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1.5 transition-colors cursor-pointer"
                            title="Direct standalone tool page"
                          >
                            <Calculator className="h-4 w-4 stroke-[1.5]" /> Standalone Tool
                          </button>

                          {hasArticle ? (
                            <button
                              onClick={() => navigateTo("blog", calc.slug)}
                              className="text-gray-600 hover:text-blue-600 hover:underline flex items-center gap-1.5 transition-colors cursor-pointer"
                              title="Blog article with embedded calculator"
                            >
                              <BookOpen className="h-4 w-4 stroke-[1.5]" /> Read Article + Tool
                            </button>
                          ) : (
                            <span className="text-gray-400 italic text-[11px] font-normal">
                              Manual guide coming soon
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* VIEW: STANDALONE CALCULATOR LAYER */}
            {currentView === "calculators" && (
              activeCalculator ? (
                <div className="space-y-8 animate-fade-in" id="standalone-calculator-wrap">
                  {/* Meta details header card */}
                  <div className="bg-slate-900 text-white rounded-xl p-8 shadow-sm border border-slate-800 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 bg-gray-800/40 border-l border-b border-gray-700 text-[10px] font-mono uppercase tracking-tighter text-slate-300">
                      ID: {activeCalculator.id}
                    </div>
                    <div className="text-[10px] uppercase tracking-widest text-[#60A5FA] font-mono font-bold mb-3">
                      Standalone Utility // Target Search Term: "{activeCalculator.keyword}"
                    </div>
                    <h1 className="text-3xl sm:text-4xl font-serif font-semibold text-white leading-tight mb-3">
                      {activeCalculator.h1}
                    </h1>
                    <p className="text-xs sm:text-sm font-sans font-light text-slate-200 leading-relaxed max-w-3xl mt-2">
                      Provide exact metrics underneath. Fully client-side spreadsheet compilation ensures instantaneous evaluations under modern Core Web Vitals criteria.
                    </p>
                  </div>

                  {/* Actual Interactive calculation core */}
                  <CalculatorEngine id={activeCalculator.id} />

                  {/* Strict Internal Linking checklist required for Seobility score checks */}
                  <div className="bg-white p-8 rounded-xl border border-gray-200 shadow-sm">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block mb-4">
                      Associated Financial Tools (Crawl Cycle Archive)
                    </span>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs leading-normal">
                      {CALCULATORS.filter((c) => activeCalculator.relatedIds.includes(c.id)).map((c) => (
                        <button
                          key={c.id}
                          onClick={() => navigateTo("calculators", c.slug)}
                          className="p-4 bg-slate-50 border border-slate-200 rounded-lg hover:border-blue-500 hover:bg-blue-50/20 transition-all text-left flex flex-col cursor-pointer"
                        >
                          <span className="text-[9px] font-mono text-blue-600 uppercase tracking-widest font-bold">Related Calculator</span>
                          <span className="mt-1.5 block font-serif font-black text-slate-900 text-sm hover:text-blue-600">{c.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ) : activeSlug ? (
                /* CALCULATOR 404 NOT FOUND SECTION */
                <div className="bg-white p-12 sm:p-16 rounded-xl border border-gray-200 text-center shadow-sm space-y-6 animate-fade-in" id="calc-404-wrap">
                  <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mx-auto border border-rose-200 shadow-inner">
                    <AlertTriangle className="h-8 w-8 stroke-[1.5]" />
                  </div>
                  <div className="space-y-2">
                    <h1 className="font-serif text-3xl font-black text-slate-900">Utility Not Found (404)</h1>
                    <p className="text-xs sm:text-sm text-slate-650 max-w-md mx-auto leading-relaxed">
                      The tool matches no active crawler index. It may have been relocated, or doesn't meet the newest IRS tax schedule parameters.
                    </p>
                  </div>
                  <button
                    onClick={() => navigateTo("home")}
                    className="px-6 py-3.5 bg-blue-650 hover:bg-blue-700 text-white font-bold text-xs tracking-widest uppercase rounded shadow transition-all cursor-pointer inline-flex items-center gap-2"
                  >
                    <ArrowLeft className="h-4 w-4" /> Return to Main Directory
                  </button>
                </div>
              ) : (
                /* STANDALONE DIRECTORY INDEX FOR /#/calculators */
                <div className="space-y-8 animate-fade-in" id="standalone-directory-list">
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-8 shadow-sm">
                    <h1 className="font-serif text-4xl font-semibold text-slate-950 mb-3 tracking-tight">
                      Financial Directory &amp; Calculations Index
                    </h1>
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-3xl">
                      Access our complete professional collection of client-side estimation models, IRS 1099 compliance tables, and currency tax schedulers below.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {CALCULATORS.map((calc) => (
                      <div
                        key={calc.id}
                        className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between hover:border-blue-500 hover:shadow-md transition-all"
                      >
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono text-indigo-600 uppercase tracking-widest font-bold">
                              Category: {calc.category}
                            </span>
                          </div>
                          <h3 className="font-serif text-xl font-black text-slate-900 leading-snug">
                            {calc.name}
                          </h3>
                          <p className="text-xs text-slate-600 leading-relaxed">
                            {calc.description}
                          </p>
                        </div>
                        <button
                          onClick={() => navigateTo("calculators", calc.slug)}
                          className="mt-6 inline-flex items-center gap-2 text-xs font-bold font-mono uppercase tracking-wider text-blue-600 hover:text-blue-700 hover:underline text-left cursor-pointer transition-all"
                        >
                          Launch Active Metric <ArrowRight className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )
            )}

            {/* VIEW: BLOG LAYER (WITH SINGLE CHANNELS OR GENERAL DIRECTORY) */}
            {currentView === "blog" && (
              activeArticle ? (
                <article className="space-y-8 bg-white p-8 sm:p-10 rounded-xl border border-gray-200 shadow-sm animate-fade-in" id="blog-article-wrap">
                  {/* Article Header info */}
                  <div className="space-y-4 pb-6 border-b border-gray-100">
                    <span className="px-3 py-1 rounded-sm text-[10px] font-mono uppercase tracking-widest bg-blue-50 text-blue-700 border border-blue-200 font-bold">
                      {activeArticle.category}
                    </span>
                    <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-black text-gray-950 leading-tight tracking-tight mt-2">
                      {activeArticle.h1}
                    </h1>
                    <div className="flex flex-wrap items-center gap-4 text-[10px] text-slate-600 mt-3 font-mono uppercase tracking-wider font-semibold">
                      <span className="flex items-center gap-1">
                        <User className="h-3.5 w-3.5 text-blue-600" /> By {activeArticle.author}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5 text-slate-500" /> {activeArticle.publishDate}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5 text-slate-500" /> {activeArticle.readTime}
                      </span>
                    </div>
                  </div>

                  {/* Article textual paragraphs */}
                  <div className="prose prose-slate max-w-none text-xs sm:text-sm leading-relaxed text-slate-700 space-y-5 font-sans">
                    {activeArticle.content.map((p, idx) => (
                      <p key={idx} className="first-letter:text-xl first-letter:font-serif first-letter:font-bold text-slate-700">
                        {p}
                      </p>
                    ))}
                  </div>

                  {/* EMBEDDED CALCULATION CORE - Satisfies rule: "Mix ALL blogs with their calculators" */}
                  {activeArticle.calculatorId && (
                    <div className="my-10" id="embedded-interactive-calc">
                      <div className="bg-slate-900 text-white p-4 rounded-t-xl text-[10px] font-mono uppercase tracking-widest font-bold flex items-center justify-between gap-2 border border-slate-800">
                        <span className="flex items-center gap-2">
                          <Calculator className="h-4 w-4 text-[#60A5FA]" />
                          <span>Interactive Compliance Estimator Dashboard</span>
                        </span>
                        <span className="text-[9px] text-[#A5B4FC] bg-[#312E81] text-white px-2 py-0.5 rounded-sm">COMPLIANT</span>
                      </div>
                      <div className="border border-slate-200 rounded-b-xl overflow-hidden bg-white shadow-inner">
                        <CalculatorEngine id={activeArticle.calculatorId} />
                      </div>
                    </div>
                  )}

                  {/* FAQ section for schema JSON-LD crawl benefits */}
                  <div className="border-t border-gray-200 pt-8 mt-10">
                    <h2 className="text-2xl font-serif font-bold text-slate-950 mb-6">
                      Frequently Asked Questions (FAQ)
                    </h2>
                    <div className="space-y-4" id="article-faqs">
                      {activeArticle.faqs.map((faq, i) => (
                        <div key={i} className="p-6 bg-slate-50 border border-slate-200 relative rounded-lg">
                          <strong className="block text-slate-950 font-sans font-bold text-sm mb-2">
                            Q: {faq.question}
                          </strong>
                          <span className="block text-slate-700 text-xs sm:text-sm leading-relaxed font-sans">
                            A: {faq.answer}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Contextual internal linking anchor list */}
                  <div className="p-6 bg-blue-50/70 border border-blue-150 text-xs text-gray-800 rounded-xl">
                    <span className="font-mono text-[10px] uppercase tracking-widest font-bold text-blue-700 block mb-3">
                      Internal Knowledge Library Index
                    </span>
                    <div className="flex flex-wrap gap-x-6 gap-y-3">
                      {activeArticle.relatedSlugs.map((slug) => {
                        const relateArt = ARTICLES.find((r) => r.slug === slug);
                        return relateArt ? (
                          <button
                            key={slug}
                            onClick={() => navigateTo("blog", slug)}
                            className="text-slate-900 hover:text-blue-700 hover:underline text-left font-serif font-bold flex items-center gap-1.5 cursor-pointer"
                          >
                            <BookOpen className="h-3.5 w-3.5 shrink-0 text-blue-500" /> {relateArt.title.substring(0, 42)}...
                          </button>
                        ) : null;
                      })}
                    </div>
                  </div>
                </article>
              ) : activeSlug ? (
                /* BLOG 404 NOT FOUND SECTION */
                <div className="bg-white p-12 sm:p-16 rounded-xl border border-gray-200 text-center shadow-sm space-y-6 animate-fade-in" id="blog-404-wrap">
                  <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mx-auto border border-rose-200 shadow-inner">
                    <AlertTriangle className="h-8 w-8 stroke-[1.5]" />
                  </div>
                  <div className="space-y-2">
                    <h1 className="font-serif text-3xl font-black text-slate-900">Document Not Found (404)</h1>
                    <p className="text-xs sm:text-sm text-slate-650 max-w-md mx-auto leading-relaxed">
                      We found no article under this slug directory. It is likely a crawling error or draft document.
                    </p>
                  </div>
                  <button
                    onClick={() => navigateTo("blog")}
                    className="px-6 py-3.5 bg-blue-650 hover:bg-blue-700 text-white font-bold text-xs tracking-widest uppercase rounded shadow transition-all cursor-pointer inline-flex items-center gap-2"
                  >
                    <ArrowLeft className="h-4 w-4" /> Go to Trade Guides
                  </button>
                </div>
              ) : (
                /* REVOLUTIONARY HIGH-CONTRAST BENTO BLOG DIRECTORY AT /#/blog */
                <div className="space-y-8 animate-fade-in" id="blog-directory-index">
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-8 shadow-sm">
                    <h1 className="font-serif text-4xl font-semibold text-slate-950 mb-3 tracking-tight">
                      IRS Compliance &amp; Self-Employment Library
                    </h1>
                    <p className="text-xs sm:text-sm text-slate-650 leading-relaxed max-w-3xl">
                      Review complete tax analyses, international tariff frameworks, digital merchant payment audits, and Schedule C optimization guidelines written by trade specialists.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 gap-6">
                    {ARTICLES.map((art) => (
                      <div
                        key={art.id}
                        className="bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between hover:border-blue-500 hover:shadow-md transition-all"
                      >
                        <div className="space-y-3">
                          <div className="flex flex-wrap items-center gap-3">
                            <span className="px-2.5 py-0.5 rounded-sm text-[9px] font-mono uppercase bg-blue-50 text-blue-700 border border-blue-200 font-bold">
                              {art.category}
                            </span>
                            <span className="text-[10px] font-mono text-slate-500 font-medium flex items-center gap-1">
                              <Clock className="h-3.5 w-3.5" /> {art.readTime}
                            </span>
                          </div>
                          <h3 className="font-serif text-2xl font-black text-slate-950 leading-snug">
                            {art.title}
                          </h3>
                          <p className="text-xs sm:text-sm text-slate-650 leading-relaxed max-w-3xl">
                            {art.metaDescription}
                          </p>
                        </div>
                        <div className="mt-6 pt-5 border-t border-slate-100 flex items-center justify-between">
                          <span className="text-[10px] font-mono text-slate-500 font-semibold uppercase">
                            Published: {art.publishDate} // By {art.author}
                          </span>
                          <button
                            onClick={() => navigateTo("blog", art.slug)}
                            className="inline-flex items-center gap-1.5 text-xs font-bold font-mono uppercase tracking-wider text-blue-600 hover:text-blue-700 hover:underline cursor-pointer"
                          >
                            Read Full Guide <ChevronRight className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )
            )}
          </div>

          {/* Right Column (Dynamic SEO Diagnostic Sidebar Widget) */}
          <div className="lg:col-span-4 space-y-6">
            <SEOAuditor
              currentView={currentView}
              activeSlug={activeSlug}
              pageTitle={
                currentView === "home"
                  ? "Corporate Fin Calculators & 1099 Tax Estimators | TheMetricApp"
                  : currentView === "calculators" && activeCalculator
                  ? activeCalculator.title
                  : currentView === "blog" && activeArticle
                  ? activeArticle.title
                  : "The Metric App Portal"
              }
              metaDesc={
                currentView === "home"
                  ? "Explore over 50 completely free financial calculators, commercial tariff systems, and tax write-off trackers for self-employed individuals."
                  : currentView === "calculators" && activeCalculator
                  ? activeCalculator.metaDescription
                  : currentView === "blog" && activeArticle
                  ? activeArticle.metaDescription
                  : "Calculation widgets for modern finance."
              }
              h1Text={
                currentView === "home"
                  ? "Explore over 50 free financial calculators"
                  : currentView === "calculators" && activeCalculator
                  ? activeCalculator.h1
                  : currentView === "blog" && activeArticle
                  ? activeArticle.h1
                  : ""
              }
              internalLinkCount={getInternalLinkCount()}
              hasSchema={true}
            />

            {/* Small Quick-Facts block */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-widest mb-2 flex items-center gap-1">
                <Info className="h-4 w-4 text-slate-400 shrink-0" /> Auditer Guidelines
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                By setting dynamic <code>document.title</code> and metadata headers asynchronously depending on hash state routing, we guarantee that automatic auditing systems like <strong>Seobility</strong> evaluate each calculator tool precisely.
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Global crawl-optimized Footer */}
      <Footer onNavigate={navigateTo} />
    </div>
  );
}
