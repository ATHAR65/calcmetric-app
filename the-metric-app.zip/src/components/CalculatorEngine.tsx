/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { DollarSign, Percent, AlertCircle, Info, Landmark, Briefcase, RefreshCw, Calculator } from "lucide-react";

interface CalculatorEngineProps {
  id: string;
}

export default function CalculatorEngine({ id }: CalculatorEngineProps) {
  // --- STATE FOR DOORDASH ESTIMATOR ---
  const [ddGross, setDdGross] = useState<number>(12500);
  const [ddMileage, setDdMileage] = useState<number>(3100);
  const [ddExpenses, setDdExpenses] = useState<number>(450);

  // --- STATE FOR SIDE HUSTLE ESTIMATOR ---
  const [shRevenue, setShRevenue] = useState<number>(18500);
  const [shExpenses, setShExpenses] = useState<number>(1400);
  const [shW2Salary, setShW2Salary] = useState<number>(65000);

  // --- STATE FOR US IMPORT TARIFFS ---
  const [tariffValue, setTariffValue] = useState<number>(15000);
  const [tariffCountry, setTariffCountry] = useState<string>("general"); // general / china / canada-mexico
  const [tariffSurcharge, setTariffSurcharge] = useState<string>("none"); // none / steel (25%) / alum (10%)
  const [tariffFreight, setTariffFreight] = useState<number>(1800);
  const [tariffInsurance, setTariffInsurance] = useState<number>(120);

  // --- STATE FOR STRIPE MERCHANTS ---
  const [stripeAmount, setStripeAmount] = useState<number>(500);
  const [stripeCardType, setStripeCardType] = useState<string>("domestic"); // domestic (2.9% + 30c) / international (3.9% + 30c) / ach (0.8% max $5)

  // --- STATE FOR PAYPAL FEE MERCHANTS ---
  const [paypalAmount, setPaypalAmount] = useState<number>(500);
  const [paypalType, setPaypalType] = useState<string>("standard"); // standard (3.49% + 49c) / f_f (0) / qr (1.9% + 10c)

  // --- STATE FOR UK VAT ---
  const [vatAmount, setVatAmount] = useState<number>(240);
  const [vatRate, setVatRate] = useState<number>(20); // 20% standard, 5% reduced, 0%
  const [vatAction, setVatAction] = useState<string>("add"); // add / remove

  // --- STATE FOR SELF-EMPLOYMENT TAX ---
  const [seNetProfit, setSeNetProfit] = useState<number>(35000);

  // --- STATE FOR HOURLY WAGE CONVERTER ---
  const [hourlyWage, setHourlyWage] = useState<number>(28);
  const [hourlyHours, setHourlyHours] = useState<number>(40);
  const [hourlyWeeks, setHourlyWeeks] = useState<number>(52);

  // Trigger scroll to tool when ID changes
  useEffect(() => {
    const el = document.getElementById("active-tool-anchor");
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [id]);

  // --- RENDER DOORDASH ESTIMATOR ---
  const renderDoorDash = () => {
    // 2026 Mileage rate standard: 70 cents per mile
    const mileageDeduction = ddMileage * 0.70;
    const totalDeductions = mileageDeduction + ddExpenses;
    const netProfit = Math.max(0, ddGross - totalDeductions);

    // Schedule SE calculation
    const taxableIncomeSE = netProfit * 0.9235;
    const selfEmploymentTax = taxableIncomeSE * 0.153; // 15.3% standard SE

    const suggestedQuarterly = selfEmploymentTax / 4;

    return (
      <div className="space-y-6" id="doordash-calc-form">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Gross DoorDash Revenue ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="number"
                value={ddGross || ""}
                onChange={(e) => setDdGross(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-4 text-sm"
              />
            </div>
            <span className="text-[10px] text-slate-400">Total pay before deductions</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Standard Business Miles</label>
            <input
              type="number"
              value={ddMileage || ""}
              onChange={(e) => setDdMileage(Math.max(0, Number(e.target.value)))}
              className="w-full rounded-lg border border-slate-200 py-2 px-3 text-sm"
            />
            <span className="text-[10px] text-slate-400">Miles tracked during deliveries</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Other Operating Expenses ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="number"
                value={ddExpenses || ""}
                onChange={(e) => setDdExpenses(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-4 text-sm"
              />
            </div>
            <span className="text-[10px] text-slate-400">Phone bills, hot bags, road tolls</span>
          </div>
        </div>

        {/* Results grid */}
        <div className="bg-slate-50 border border-slate-100 rounded-xl p-5" id="doordash-results">
          <h4 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2 mb-4">Calculation Output (2026 Standards)</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-[10px] text-slate-400 block font-semibold uppercase">Mileage Mileage Deduction</span>
              <span className="text-base font-extrabold text-slate-950 mt-1 block">${mileageDeduction.toFixed(2)}</span>
              <span className="text-[9px] text-slate-500 font-mono">@ $0.70 per mile</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-[10px] text-slate-400 block font-semibold uppercase">Net Taxable Profit</span>
              <span className="text-base font-extrabold text-slate-950 mt-1 block">${netProfit.toFixed(2)}</span>
              <span className="text-[9px] text-emerald-600">Revenues - expenses</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-[10px] text-slate-400 block font-semibold uppercase">Est. Self-Employment Tax</span>
              <span className="text-base font-extrabold text-blue-600 mt-1 block">${selfEmploymentTax.toFixed(2)}</span>
              <span className="text-[9px] text-slate-500 font-mono">15.3% on 92.35% profit</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100 bg-emerald-50 border-emerald-100">
              <span className="text-[10px] text-emerald-800 block font-bold uppercase">suggested Quarterly Save</span>
              <span className="text-base font-black text-emerald-700 mt-1 block">${suggestedQuarterly.toFixed(2)}</span>
              <span className="text-[9px] text-emerald-600">Save for quarterly taxes</span>
            </div>
          </div>

          {/* Simple reactive Visual diagram (SVG) */}
          <div className="mt-4 pt-4 border-t border-slate-200">
            <span className="text-xs font-bold text-slate-700 block mb-2">Earnings Split Visualizer</span>
            <div className="w-full bg-slate-200 h-6 rounded-full overflow-hidden flex" id="earnings-split-diagram">
              <div
                style={{ width: `${Math.min(100, Math.max(5, (netProfit / ddGross) * 100 || 0))}%` }}
                className="bg-emerald-500 flex items-center justify-center text-[10px] text-white font-bold transition-all"
                title="Your kept net profit"
              >
                Keep: {((netProfit / ddGross) * 100 || 0).toFixed(0)}%
              </div>
              <div
                style={{ width: `${Math.min(100, Math.max(5, (selfEmploymentTax / ddGross) * 100 || 0))}%` }}
                className="bg-blue-500 flex items-center justify-center text-[10px] text-white font-bold transition-all"
                title="Self Employment duty"
              >
                Tax: {((selfEmploymentTax / ddGross) * 100 || 0).toFixed(0)}%
              </div>
              <div
                style={{ width: `${Math.min(100, Math.max(5, (totalDeductions / ddGross) * 100 || 0))}%` }}
                className="bg-slate-400 flex items-center justify-center text-[10px] text-white font-bold transition-all"
                title="Direct operating costs"
              >
                Write-offs: {((totalDeductions / ddGross) * 100 || 0).toFixed(0)}%
              </div>
            </div>
            <div className="flex gap-4 text-[10px] text-slate-500 mt-2 justify-center">
              <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-500"></span> Net Keep</span>
              <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-blue-500"></span> FICA Tax</span>
              <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-slate-400"></span> Deductions</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // --- RENDER SIDE HUSTLE ESTIMATOR ---
  const renderSideHustle = () => {
    const netProfit = Math.max(0, shRevenue - shExpenses);
    const seTaxable = netProfit * 0.9235;
    const selfEmploymentTax = seTaxable * 0.153;

    // Estimate income bracket standard tax rate based on W2 salary
    let incomeTaxPercent = 0.12;
    if (shW2Salary > 190000) incomeTaxPercent = 0.32;
    else if (shW2Salary > 100000) incomeTaxPercent = 0.24;
    else if (shW2Salary > 47000) incomeTaxPercent = 0.22;

    const federalIncomeTaxOnProfit = netProfit * incomeTaxPercent;
    const totalTax = selfEmploymentTax + federalIncomeTaxOnProfit;
    const remainingCash = netProfit - totalTax;

    return (
      <div className="space-y-6" id="sidehustle-calc-form">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Side Hustle Annual Revenue ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="number"
                value={shRevenue || ""}
                onChange={(e) => setShRevenue(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-4 text-sm"
              />
            </div>
            <span className="text-[10px] text-slate-400">Total gross intake</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Operating Expenses ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="number"
                value={shExpenses || ""}
                onChange={(e) => setShExpenses(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-4 text-sm"
              />
            </div>
            <span className="text-[10px] text-slate-400">Laptop, ads, software, tools</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Your Regular W-2 Salary ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="number"
                value={shW2Salary || ""}
                onChange={(e) => setShW2Salary(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-4 text-sm"
              />
            </div>
            <span className="text-[10px] text-slate-400">Determines your income tax bracket</span>
          </div>
        </div>

        {/* Results */}
        <div className="bg-slate-50 border border-slate-100 rounded-xl p-5" id="sidehustle-results">
          <h4 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2 mb-4">Annual Projections Summary</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-[10px] text-slate-400 block font-semibold uppercase">Net Business Profit</span>
              <span className="text-base font-extrabold text-slate-950 mt-1 block">${netProfit.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-[10px] text-slate-400 block font-semibold uppercase">Schedule SE (FICA) Tax</span>
              <span className="text-base font-extrabold text-blue-600 mt-1 block">${selfEmploymentTax.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-[10px] text-slate-400 block font-semibold uppercase">Income Tax Portion</span>
              <span className="text-base font-extrabold text-indigo-600 mt-1 block">${federalIncomeTaxOnProfit.toFixed(2)}</span>
              <span className="text-[9px] text-slate-500 font-mono">Assumed {(incomeTaxPercent * 100).toFixed(0)}% bracket</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100 bg-emerald-50 border-emerald-100">
              <span className="text-[10px] text-emerald-800 block font-bold uppercase">Real Take-Home After Cash</span>
              <span className="text-base font-black text-emerald-700 mt-1 block">${remainingCash.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // --- RENDER US IMPORT TARIFFS ---
  const renderUSTariffs = () => {
    // Determine duties
    let dutyRate = 0.035; // 3.5% baseline standard duty
    if (tariffCountry === "china") {
      dutyRate = 0.20; // 20% base rate surcharge for standard China categories in 2026
    } else if (tariffCountry === "mexico-canada") {
      dutyRate = 0.00; // USMCA zero duty standard
    }

    // Determine specific surcharges (Section 232 / 301)
    let surchargeRate = 0;
    if (tariffSurcharge === "steel") surchargeRate = 0.25;
    else if (tariffSurcharge === "alum") surchargeRate = 0.10;

    const baseDuty = tariffValue * dutyRate;
    const additionalTargetDuty = tariffValue * surchargeRate;

    // Merchandise processing fee (MPF): 0.3464% of cargo value, min $31.67
    const calculatedMPF = tariffValue * 0.003464;
    const finalMPF = Math.max(31.67, calculatedMPF);

    // Harbor maintenance fee (HMF): 0.125% of cargo value
    const finalHMF = tariffValue * 0.00125;

    const totalDutiesAndFees = baseDuty + additionalTargetDuty + finalMPF + finalHMF;
    const totalLandedCost = tariffValue + tariffFreight + tariffInsurance + totalDutiesAndFees;
    const effectiveDutyRatePercent = (totalDutiesAndFees / tariffValue) * 100;

    return (
      <div className="space-y-6" id="tariff-calc-form">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Declared Customs Value FOB ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="number"
                value={tariffValue || ""}
                onChange={(e) => setTariffValue(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-4 text-sm"
              />
            </div>
            <span className="text-[10px] text-slate-400">Declared price at cargo port</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Country of Origin</label>
            <select
              value={tariffCountry}
              onChange={(e) => setTariffCountry(e.target.value)}
              className="w-full rounded-lg border border-slate-200 py-2 px-3 text-sm bg-white"
            >
              <option value="general">General MFN Country — 3.5% rate</option>
              <option value="china">China Surcharges — 20.0% rate</option>
              <option value="mexico-canada">Canada/Mexico USMCA — 0.0% rate</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Section 232 / Metal Surcharge</label>
            <select
              value={tariffSurcharge}
              onChange={(e) => setTariffSurcharge(e.target.value)}
              className="w-full rounded-lg border border-slate-200 py-2 px-3 text-sm bg-white"
            >
              <option value="none">No specific metal surcharge (0%)</option>
              <option value="steel">Section 232 Steel Surcharge (25%)</option>
              <option value="alum">Section 232 Aluminum Surcharge (10%)</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Ocean/Air International Freight ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="number"
                value={tariffFreight || ""}
                onChange={(e) => setTariffFreight(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-4 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Marine Cargo Insurance Premium ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="number"
                value={tariffInsurance || ""}
                onChange={(e) => setTariffInsurance(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-4 text-sm"
              />
            </div>
          </div>
        </div>

        {/* Landed Cost output breakdown */}
        <div className="bg-slate-50 border border-slate-100 rounded-xl p-5" id="tariff-results">
          {tariffCountry === "china" && (
            <div className="mb-4 bg-amber-50 border border-amber-200 text-amber-900 rounded-lg p-3 text-xs flex gap-2">
              <AlertCircle className="h-4 w-4 shrink-0 text-amber-700 mt-0.5" />
              <div>
                <strong>China Tariff Alert:</strong> New standard rates for Chinese source commodities are currently computed with a baseline 20.0% duty, subject to upcoming November 10 federal rate revisions.
              </div>
            </div>
          )}

          <h4 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2 mb-4">US Customs Fee Valuation</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4 text-xs">
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block font-semibold uppercase">Base Duty (FOB)</span>
              <span className="text-sm font-bold text-slate-950 mt-1 block">${baseDuty.toFixed(2)}</span>
              <span className="text-[10px] text-slate-500 font-mono">{(dutyRate * 100).toFixed(1)}% rate</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block font-semibold uppercase">Sec 232 Surcharge</span>
              <span className="text-sm font-bold text-slate-950 mt-1 block">${additionalTargetDuty.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block font-semibold uppercase">MPF Surcharge</span>
              <span className="text-sm font-bold text-slate-950 mt-1 block">${finalMPF.toFixed(2)}</span>
              <span className="text-[10px] text-slate-500 font-mono">0.3464% (min $31.67)</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block font-semibold uppercase">HMF Fee (Sea port Only)</span>
              <span className="text-sm font-bold text-slate-950 mt-1 block">${finalHMF.toFixed(2)}</span>
              <span className="text-[10px] text-slate-500 font-mono">0.125% of Customs</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-200 bg-emerald-50 border-emerald-100 col-span-2 md:col-span-1">
              <span className="text-emerald-800 block font-bold uppercase">Estimated Landed Cost</span>
              <span className="text-sm font-black text-emerald-700 mt-1 block">${totalLandedCost.toFixed(2)}</span>
              <span className="text-[10px] text-emerald-600 font-bold">Effective Duty: {effectiveDutyRatePercent.toFixed(2)}%</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // --- RENDER STRIPE CALCULATOR ---
  const renderStripeCalc = () => {
    let feePercent = 0.029;
    let feeFixed = 0.30;
    let feeLabel = "Standard Domestic (2.9% + $0.30)";

    if (stripeCardType === "international") {
      feePercent = 0.039;
      feeFixed = 0.30;
      feeLabel = "International Cards (3.9% + $0.30)";
    } else if (stripeCardType === "ach") {
      feePercent = 0.008;
      feeFixed = 0;
      feeLabel = "ACH Direct Debit (0.8%, max $5)";
    }

    // Processing fee
    let stripeFeeValue = stripeAmount * feePercent + feeFixed;
    if (stripeCardType === "ach") {
      stripeFeeValue = Math.min(5.00, stripeFeeValue);
    }
    const stripeNetPayout = Math.max(0, stripeAmount - stripeFeeValue);

    // Dynamic inverse multiplier (How much to invoice so you receive exactly specified amount)
    let neededInvoice = 0;
    if (stripeAmount > 0) {
      if (stripeCardType === "ach") {
        neededInvoice = stripeAmount <= 620 ? stripeAmount / (1 - 0.008) : stripeAmount + 5.00;
      } else {
        neededInvoice = (stripeAmount + feeFixed) / (1 - feePercent);
      }
    }

    return (
      <div className="space-y-6" id="stripe-calc-form">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Target Amount ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="number"
                value={stripeAmount || ""}
                onChange={(e) => setStripeAmount(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-4 text-sm"
              />
            </div>
            <span className="text-[10px] text-slate-400">Value of credit card payload</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Stripe Service Configuration Type</label>
            <select
              value={stripeCardType}
              onChange={(e) => setStripeCardType(e.target.value)}
              className="w-full rounded-lg border border-slate-200 py-2 px-3 text-sm bg-white"
            >
              <option value="domestic">Standard Domestic Card — 2.9% + 30¢</option>
              <option value="international">International Card — 3.9% + 30¢</option>
              <option value="ach">ACH Bank Transfer — 0.8% (capped at $5)</option>
            </select>
          </div>
        </div>

        {/* Stripe Output Grid */}
        <div className="bg-slate-50 border border-slate-100 rounded-xl p-5" id="stripe-results">
          <h4 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2 mb-4">Processing Breakdown ({feeLabel})</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4 text-xs">
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block font-semibold uppercase">Total Processing Fee</span>
              <span className="text-sm font-bold text-rose-600 mt-1 block">-${stripeFeeValue.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block font-semibold uppercase">Net Payment Received</span>
              <span className="text-sm font-bold text-slate-950 mt-1 block">${stripeNetPayout.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-200 bg-emerald-50 border-emerald-100 col-span-2 md:col-span-1">
              <span className="text-emerald-800 block font-bold uppercase">Raise Invoice Charge To</span>
              <span className="text-sm font-black text-emerald-700 mt-1 block">${neededInvoice.toFixed(2)}</span>
              <span className="text-[10px] text-emerald-600">Client pays Stripe fees</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // --- RENDER PAYPAL CALCULATOR ---
  const renderPaypalCalc = () => {
    let feePercent = 0.0349;
    let feeFixed = 0.49;
    let feeLabel = "Standard Merchant Charge (3.49% + $0.49)";

    if (paypalType === "f_f") {
      feePercent = 0.00;
      feeFixed = 0.00;
      feeLabel = "Friends & Family Transfer (0% free)";
    } else if (paypalType === "qr") {
      feePercent = 0.019;
      feeFixed = 0.10;
      feeLabel = "QR Code Business Code (1.9% + $0.10)";
    }

    const payloadFeeVal = paypalAmount * feePercent + feeFixed;
    const paypalNetPayout = Math.max(0, paypalAmount - payloadFeeVal);

    // Compute markup invoice rate
    let neededInvoice = 0;
    if (paypalAmount > 0 && 1 - feePercent > 0) {
      neededInvoice = (paypalAmount + feeFixed) / (1 - feePercent);
    }

    return (
      <div className="space-y-6" id="paypal-calc-form">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Transfer Amount ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="number"
                value={paypalAmount || ""}
                onChange={(e) => setPaypalAmount(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-4 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">PayPal Payment channel</label>
            <select
              value={paypalType}
              onChange={(e) => setPaypalType(e.target.value)}
              className="w-full rounded-lg border border-slate-200 py-2 px-3 text-sm bg-white"
            >
              <option value="standard">Business standard Invoice — 3.49% + 49¢</option>
              <option value="qr">QR Code payment — 1.9% + 10¢</option>
              <option value="f_f">Friends & Family (Personal) — 0% Free</option>
            </select>
          </div>
        </div>

        {/* PayPal Output */}
        <div className="bg-slate-50 border border-slate-100 rounded-xl p-5" id="paypal-results">
          <h4 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2 mb-4">Calculation Outputs ({feeLabel})</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4 text-xs">
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block font-semibold uppercase">Total Processing Fee</span>
              <span className="text-sm font-bold text-rose-600 mt-1 block">-${payloadFeeVal.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block font-semibold uppercase">Net Profit Sent</span>
              <span className="text-sm font-bold text-slate-950 mt-1 block">${paypalNetPayout.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-200 bg-emerald-50 border-emerald-100 col-span-2 md:col-span-1">
              <span className="text-emerald-800 block font-bold uppercase">suggested Invoice Surcharge</span>
              <span className="text-sm font-black text-emerald-700 mt-1 block">${neededInvoice.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // --- RENDER UK VAT ---
  const renderUKVAT = () => {
    let computedVAT = 0;
    let net = 0;
    let gross = 0;

    const rateMult = vatRate / 100;

    if (vatAction === "add") {
      computedVAT = vatAmount * rateMult;
      net = vatAmount;
      gross = vatAmount + computedVAT;
    } else {
      // Extract from Gross
      net = vatAmount / (1 + rateMult);
      computedVAT = vatAmount - net;
      gross = vatAmount;
    }

    return (
      <div className="space-y-6" id="vat-calc-form">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Enter Transaction Amount (£)</label>
            <div className="relative">
              <span className="absolute left-3 top-2 text-sm text-slate-400">£</span>
              <input
                type="number"
                value={vatAmount || ""}
                onChange={(e) => setVatAmount(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-7 pr-4 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Select VAT Rate</label>
            <select
              value={vatRate}
              onChange={(e) => setVatRate(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-200 py-2 px-3 text-sm bg-white"
            >
              <option value={20}>UK Standard VAT Rate — 20%</option>
              <option value={5}>UK Reduced VAT Rate — 5%</option>
              <option value={0}>UK Exempt Category — 0%</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Tax Action</label>
            <select
              value={vatAction}
              onChange={(e) => setVatAction(e.target.value)}
              className="w-full rounded-lg border border-slate-200 py-2 px-3 text-sm bg-white"
            >
              <option value="add">Add VAT to net amount</option>
              <option value="remove">Extract VAT from gross receipts</option>
            </select>
          </div>
        </div>

        {/* VAT Outputs */}
        <div className="bg-slate-50 border border-slate-100 rounded-xl p-5" id="vat-results">
          <h4 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2 mb-4">HMRC Compliant Breakdown</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-xs">
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block font-semibold uppercase">Net price (excluding VAT)</span>
              <span className="text-sm font-extrabold text-slate-950 mt-1 block">£{net.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block font-semibold uppercase">VAT tax value ({vatRate}%)</span>
              <span className="text-sm font-extrabold text-blue-600 mt-1 block">£{computedVAT.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100 bg-emerald-50 border-emerald-100 col-span-2">
              <span className="text-emerald-800 block font-bold uppercase">Total invoice price (including VAT)</span>
              <span className="text-sm font-black text-emerald-700 mt-1 block">£{gross.toFixed(2)}</span>
              <span className="text-[10px] text-emerald-600">Company registration threshold threshold: £90,000 yearly turnover</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // --- RENDER SELF EMPLOYMENT TAX ---
  const renderSelfEmployment = () => {
    const adjustedNet = seNetProfit * 0.9235;
    const socialSecurityLimit = 168600; // standard ceiling limit

    // Social Security portion: 12.4% on earnings up to ceiling
    const ssTaxableProfit = Math.min(socialSecurityLimit, adjustedNet);
    const ssTax = ssTaxableProfit * 0.124;

    // Medicare portion: 2.9% on all earnings
    const medicareTax = adjustedNet * 0.029;

    const totalSETaxVal = ssTax + medicareTax;
    const halvedDeduction = totalSETaxVal / 2;

    return (
      <div className="space-y-6" id="se-calc-form">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Expected Annual Net Self-Employed Profit ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="number"
                value={seNetProfit || ""}
                onChange={(e) => setSeNetProfit(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-4 text-sm"
              />
            </div>
            <span className="text-[10px] text-slate-400">Revenue minus write-offs from Schedule C</span>
          </div>

          <div className="p-3 bg-slate-100 rounded-lg flex items-start gap-2.5 text-xs text-slate-600">
            <Info className="h-4.5 w-4.5 shrink-0 text-blue-500 mt-0.5" />
            <div>
              <strong>Schedule SE:</strong> IRS taxes self-employed at 15.3%, which comprises 12.4% Social Security and 2.9% Medicare. Taxes apply only on 92.35% of your net profits.
            </div>
          </div>
        </div>

        {/* Outputs */}
        <div className="bg-slate-50 border border-slate-100 rounded-xl p-5" id="se-results">
          <h4 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2 mb-4">IRS Tax Schedule Schedule SE Summary</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-xs">
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block font-semibold uppercase">12.4% Social Security</span>
              <span className="text-sm font-bold text-slate-950 mt-1 block">${ssTax.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block font-semibold uppercase">2.9% Medicare Portion</span>
              <span className="text-sm font-bold text-slate-950 mt-1 block">${medicareTax.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100 bg-blue-50 border-blue-100">
              <span className="text-blue-850 block font-bold uppercase">Total Self Employment Duty</span>
              <span className="text-sm font-black text-blue-700 mt-1 block">${totalSETaxVal.toFixed(2)}</span>
              <span className="text-[10px] text-blue-600">Schedule SE duty</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100 bg-emerald-50 border-emerald-100">
              <span className="text-emerald-850 block font-bold uppercase">IRS Adjustable Tax Deduction</span>
              <span className="text-sm font-black text-emerald-700 mt-1 block">${halvedDeduction.toFixed(2)}</span>
              <span className="text-[10px] text-emerald-600">50% SE deduction write-off</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // --- RENDER HOURLY WAGE CONVERTER ---
  const renderHourlyWage = () => {
    const weeklyRate = hourlyWage * hourlyHours;
    const annualBase = weeklyRate * hourlyWeeks;
    const monthlyRate = annualBase / 12;
    const biweeklyRate = annualBase / 26;

    return (
      <div className="space-y-6" id="hourly-calc-form">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Raw Hourly Wage Pay Rate ($)</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="number"
                value={hourlyWage || ""}
                onChange={(e) => setHourlyWage(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-4 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Weekly Contracted Hours</label>
            <input
              type="number"
              value={hourlyHours || ""}
              onChange={(e) => setHourlyHours(Math.max(0, Number(e.target.value)))}
              className="w-full rounded-lg border border-slate-200 py-2 px-3 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">Paid Work Weeks Per Year</label>
            <input
              type="number"
              value={hourlyWeeks || ""}
              onChange={(e) => setHourlyWeeks(Math.max(1, Math.min(52, Number(e.target.value))))}
              className="w-full rounded-lg border border-slate-200 py-2 px-3 text-sm"
            />
          </div>
        </div>

        {/* Wage Brackets Output */}
        <div className="bg-slate-50 border border-slate-100 rounded-xl p-5" id="hourly-results">
          <h4 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2 mb-4">Salary conversion brackets</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-medium">
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block lowercase first-letter:uppercase">Weekly take home</span>
              <span className="text-base font-extrabold text-slate-900 mt-1 block">${weeklyRate.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block lowercase first-letter:uppercase">Bi-weekly (26 periods)</span>
              <span className="text-base font-extrabold text-slate-900 mt-1 block">${biweeklyRate.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100">
              <span className="text-slate-400 block lowercase first-letter:uppercase">Average monthly salary</span>
              <span className="text-base font-extrabold text-slate-900 mt-1 block">${monthlyRate.toFixed(2)}</span>
            </div>
            <div className="bg-white p-3 rounded-lg border border-slate-100 bg-emerald-50 border-emerald-100">
              <span className="text-emerald-850 block font-bold uppercase">Estimated Annual salary base</span>
              <span className="text-base font-black text-emerald-700 mt-1 block">${annualBase.toFixed(2)}</span>
              <span className="text-[10px] text-emerald-600 block">Based on {hourlyHours * hourlyWeeks} yearly hours</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Wrapper dispatcher
  const renderActiveCalculator = () => {
    switch (id) {
      case "doordash-tax-estimator":
        return renderDoorDash();
      case "side-hustle-tax-calculator":
        return renderSideHustle();
      case "us-import-tariff-calculator":
        return renderUSTariffs();
      case "stripe-fee-merchant-calculator":
        return renderStripeCalc();
      case "paypal-fee-merchant-calculator":
        return renderPaypalCalc();
      case "vat-calculator-uk":
        return renderUKVAT();
      case "self-employment-tax-calculator":
        return renderSelfEmployment();
      case "hourly-wage-calculator-us":
        return renderHourlyWage();
      default:
        return (
          <div className="p-8 text-center text-slate-500 text-sm">
            <p>Calculator formula rendering engine is loaded.</p>
          </div>
        );
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 relative overflow-hidden" id={`calc-wrap-${id}`}>
      {/* Visual background anchor helper for hash changes */}
      <span id="active-tool-anchor" className="absolute -top-24 left-0"></span>

      <div className="flex items-center gap-2 mb-4">
        <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
          <Calculator className="h-5 w-5" />
        </div>
        <div className="font-bold text-slate-900 text-base">Interactive Calculators Portal</div>
      </div>

      <hr className="border-slate-100 mb-6" />

      {renderActiveCalculator()}
    </div>
  );
}
