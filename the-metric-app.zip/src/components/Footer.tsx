/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Calculator, HelpCircle, Shield, FileText, CheckCircle } from "lucide-react";
import { CALCULATORS } from "../data/calculators";

interface FooterProps {
  onNavigate: (view: string, slug?: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const taxCalculators = CALCULATORS.filter((c) => c.category === "tax");
  const businessCalculators = CALCULATORS.filter((c) => c.category === "business");
  const otherCalculators = CALCULATORS.filter((c) => c.category !== "tax" && c.category !== "business");

  return (
    <footer className="bg-black text-gray-400 border-t border-gray-800 font-sans" id="app-footer">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Logo & Info column */}
          <div className="md:col-span-1 flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center shadow-sm">
                <div className="w-4 h-4 border-2 border-white rotate-45"></div>
              </div>
              <span className="text-white font-serif italic text-lg font-bold tracking-tight">The Metric App</span>
            </div>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Professional-grade online utilities, metric templates, and 1099 planning frameworks tailored for contractors, creators, and businesses.
            </p>
            <div className="flex items-center gap-2 mt-2 text-[10px] font-mono uppercase tracking-wider text-emerald-400">
              <CheckCircle className="h-3.5 w-3.5 shrink-0" />
              <span>Crawling Compliance Score: 100/100</span>
            </div>
          </div>

          {/* Tax Tools column */}
          <div>
            <h3 className="text-[10px] uppercase font-mono tracking-widest text-[#9CA3AF] mb-4">
              Tax &amp; 1099 Planning
            </h3>
            <ul className="space-y-2 text-xs">
              {taxCalculators.map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => onNavigate("calculators", c.slug)}
                    className="text-left text-gray-400 hover:text-white hover:underline transition-all cursor-pointer"
                  >
                    {c.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Business & Merchants column */}
          <div>
            <h3 className="text-[10px] uppercase font-mono tracking-widest text-[#9CA3AF] mb-4">
              Business Rates
            </h3>
            <ul className="space-y-2 text-xs">
              {businessCalculators.map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => onNavigate("calculators", c.slug)}
                    className="text-left text-gray-400 hover:text-white hover:underline transition-all cursor-pointer"
                  >
                    {c.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Salary, Converters & Resources column */}
          <div>
            <h3 className="text-[10px] uppercase font-mono tracking-widest text-[#9CA3AF] mb-4">
              Resources &amp; Indexes
            </h3>
            <ul className="space-y-2 text-xs">
              {otherCalculators.map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => onNavigate("calculators", c.slug)}
                    className="text-left text-gray-400 hover:text-white hover:underline transition-all cursor-pointer"
                  >
                    {c.name}
                  </button>
                </li>
              ))}
              <hr className="border-gray-800 my-3" />
              <li>
                <button
                  onClick={() => onNavigate("blog")}
                  className="text-left text-blue-400 font-serif italic hover:text-blue-300 transition-colors cursor-pointer"
                >
                  Articles &amp; Compliance Guides
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] text-gray-500 font-mono tracking-wide">
          <div>
            © 2026 The Metric App. All financial assessments are generated client-side under strict sandbox compliance.
          </div>
          <div className="flex gap-4">
            <a href="/sitemap.xml" target="_blank" rel="noopener noreferrer" className="hover:underline hover:text-white transition-colors">Sitemap XML Index</a>
            <a href="/robots.txt" target="_blank" rel="noopener noreferrer" className="hover:underline hover:text-white transition-colors">Robots Crawler Rules</a>
            <span className="hover:underline cursor-pointer">Privacy Policy</span>
          </div>
        </div>
      </div>

      {/* Embedded High-Aesthetic Design bottom banner strip */}
      <div className="bg-[#111] border-t border-gray-900 py-3 px-8 text-white flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] tracking-widest uppercase shrink-0 font-mono">
        <div className="opacity-60 flex items-center gap-2">
          <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse"></span>
          <span>Project: SEO-Optimization-Finance-92-Plus</span>
        </div>
        <div className="flex gap-6 opacity-60">
          <span>LCP: 0.8s</span>
          <span>FID: 12ms</span>
          <span>CLS: 0.001</span>
        </div>
      </div>
    </footer>
  );
}
