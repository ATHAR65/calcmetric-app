/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Search, Calculator, BookOpen, ChevronRight, Menu, X, Landmark, Compass } from "lucide-react";

interface HeaderProps {
  currentView: string;
  activeSlug: string;
  onNavigate: (view: string, slug?: string) => void;
  searchTerm: string;
  onSearchChange: (term: string) => void;
}

export default function Header({
  currentView,
  activeSlug,
  onNavigate,
  searchTerm,
  onSearchChange,
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const viewClasses = (view: string) =>
    `px-3 py-2 rounded-md text-sm font-medium transition-colors ${
      currentView === view
        ? "bg-slate-900 text-white"
        : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
    }`;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-gray-200 bg-white/95 backdrop-blur-md" id="app-header">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center">
            <button
              onClick={() => {
                onNavigate("home");
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-3 transition-opacity hover:opacity-90 align-middle"
              id="header-logo-btn"
            >
              <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center self-center shadow-sm shrink-0">
                <div className="w-4 h-4 border-2 border-white rotate-45"></div>
              </div>
              <span className="font-bold text-lg tracking-tight uppercase text-gray-900 font-sans">
                THE<span className="text-blue-600 underline underline-offset-4 decoration-2 font-extrabold">METRIC</span>
              </span>
            </button>
          </div>

          {/* Desktop Search */}
          <div className="hidden md:block flex-1 max-w-md mx-4">
            <div className="relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search calculators (e.g. tax, Stripe, VAT)..."
                value={searchTerm}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full rounded-lg border border-gray-200 py-1.5 pl-10 pr-4 text-xs font-mono text-gray-900 bg-gray-50 focus:border-blue-600 focus:bg-white focus:outline-none transition-all"
                id="desktop-search-input"
              />
              {searchTerm && (
                <button
                  onClick={() => onSearchChange("")}
                  className="absolute inset-y-0 right-0 flex items-center pr-3 text-xs text-gray-400 hover:text-gray-650"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-500 italic">
            <button
              id="nav-home"
              onClick={() => onNavigate("home")}
              className={`transition-colors cursor-pointer ${
                currentView === "home"
                  ? "text-blue-600 font-bold underline underline-offset-4 not-italic"
                  : "text-gray-500 hover:text-gray-900"
              }`}
            >
              Explore Directory
            </button>
            <button
              id="nav-calculators"
              onClick={() => onNavigate("calculators")}
              className={`flex items-center gap-1.5 transition-colors cursor-pointer ${
                currentView === "calculators"
                  ? "text-blue-600 font-bold underline underline-offset-4 not-italic"
                  : "text-gray-500 hover:text-gray-900"
              }`}
            >
              <Calculator className="h-4 w-4 shrink-0" /> Calculator Tools
            </button>
            <button
              id="nav-blogs"
              onClick={() => onNavigate("blog")}
              className={`flex items-center gap-1.5 transition-colors cursor-pointer ${
                currentView === "blog"
                  ? "text-blue-600 font-bold underline underline-offset-4 not-italic"
                  : "text-gray-500 hover:text-gray-900"
              }`}
            >
              <BookOpen className="h-4 w-4 shrink-0" /> Guidelines &amp; Articles
            </button>
          </nav>

          {/* Core Web Vitals Badge */}
          <div className="hidden lg:flex items-center">
            <div className="flex items-center gap-2 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider font-mono">Web Vitals: 99</span>
            </div>
          </div>

          {/* Mobile menu toggle */}
          <div className="flex items-center gap-2 md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-lg text-gray-500 hover:text-gray-900 hover:bg-gray-100"
              aria-label="Toggle Menu"
              id="mobile-menu-toggle"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-slate-200 bg-white" id="mobile-menu-container">
          <div className="px-4 pt-2 pb-4 space-y-3">
            {/* Mobile Search */}
            <div className="relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <Search className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="text"
                placeholder="Search tools & articles..."
                value={searchTerm}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full rounded-lg border border-slate-200 py-1.5 pl-10 pr-4 text-sm text-slate-900 bg-slate-50 focus:outline-none"
                id="mobile-search-input"
              />
            </div>

            {/* Mobile Links */}
            <div className="grid grid-cols-1 gap-1">
              <button
                onClick={() => {
                  onNavigate("home");
                  setMobileMenuOpen(false);
                }}
                className={`flex items-center w-full px-3 py-2 rounded-lg text-left text-sm font-medium leading-none ${
                  currentView === "home" ? "bg-slate-100 text-slate-950 font-bold" : "text-slate-600"
                }`}
              >
                <Compass className="h-4 w-4 mr-2" /> Explore Directory
              </button>
              <button
                onClick={() => {
                  onNavigate("calculators");
                  setMobileMenuOpen(false);
                }}
                className={`flex items-center w-full px-3 py-2 rounded-lg text-left text-sm font-medium leading-none ${
                  currentView === "calculators" ? "bg-slate-100 text-slate-955 font-bold" : "text-slate-600"
                }`}
              >
                <Calculator className="h-4 w-4 mr-2" /> Financial Tools
              </button>
              <button
                onClick={() => {
                  onNavigate("blog");
                  setMobileMenuOpen(false);
                }}
                className={`flex items-center w-full px-3 py-2 rounded-lg text-left text-sm font-medium leading-none ${
                  currentView === "blog" ? "bg-slate-100 text-slate-955 font-bold" : "text-slate-600"
                }`}
              >
                <BookOpen className="h-4 w-4 mr-2" /> Comprehensive Guides
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
