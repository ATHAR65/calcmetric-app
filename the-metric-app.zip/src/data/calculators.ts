/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CalculatorConfig } from "../types";

export const CALCULATORS: CalculatorConfig[] = [
  {
    id: "doordash-tax-estimator",
    slug: "doordash-tax-estimator",
    name: "DoorDash Tax Estimator",
    category: "tax",
    keyword: "DoorDash tax calculator",
    title: "DoorDash Tax Calculator 2026 — Free 1099 & SE Tax Estimator | TheMetricApp",
    metaDescription: "Estimate your DoorDash 1099 taxes instantly. Calculate self-employment tax, mileage deductions & suggested quarterly savings. Free, no signup required.",
    h1: "DoorDash Tax Calculator for Dashers (2026)",
    description: "Enter your gross delivery earnings, standard business mileage, and other operating expenses to calculate your net 1099 profits, self-employment taxes, and suggested quarterly IRS withholdings.",
    relatedIds: ["side-hustle-tax-calculator", "self-employment-tax-calculator", "hourly-wage-calculator-us"]
  },
  {
    id: "side-hustle-tax-calculator",
    slug: "side-hustle-tax-calculator",
    name: "Side Hustle Tax Calculator",
    category: "tax",
    keyword: "side hustle tax calculator",
    title: "Side Hustle Tax Calculator 2026 — Free 1099 Income Tax Estimator | TheMetricApp",
    metaDescription: "Calculate estimated taxes on your side hustle income in seconds. Covers self-employment tax, federal bracket adjustments & net profit. No signup.",
    h1: "Side Hustle Income Tax Calculator (2026)",
    description: "Are you running a freelancing gig, Etsy store, or consulting business on the side? Use this calculator to estimate federal income taxes and self-employment taxes (Schedule SE) on your side income.",
    relatedIds: ["doordash-tax-estimator", "self-employment-tax-calculator", "stripe-fee-merchant-calculator"]
  },
  {
    id: "us-import-tariff-calculator",
    slug: "us-import-tariff-calculator",
    name: "US Import Tariff Calculator",
    category: "business",
    keyword: "US import tariff calculator",
    title: "US Import Tariff Calculator 2026 — Duties, Section 232 & Landed Cost | TheMetricApp",
    metaDescription: "Calculate US import duties, Section 301/232 tariff surcharges, MPF, and HMF. Get total landed commercial cost for standard cargo. Free & instant.",
    h1: "US Import Tariff & Landed Cost Calculator (2026)",
    description: "Easily compute your customs value, base import duty, merchandise processing fees (MPF), harbor maintenance fees (HMF), and specific country surcharges to find your true landed cargo cost.",
    relatedIds: ["stripe-fee-merchant-calculator", "paypal-fee-merchant-calculator", "vat-calculator-uk"]
  },
  {
    id: "stripe-fee-merchant-calculator",
    slug: "stripe-fee-merchant-calculator",
    name: "Stripe Merchant Fee Calculator",
    category: "business",
    keyword: "Stripe fee calculator",
    title: "Stripe Fee Calculator 2026 — Calculate Fees & Net Transaction Payouts | TheMetricApp",
    metaDescription: "Calculate exact Stripe fees per credit card transaction or invoice. Find out how much you must charge to receive a specific net amount. Free & simple.",
    h1: "Stripe Fee & Net Payout Calculator (2026)",
    description: "Determine exact payment gateway costs based on domestic vs international cards, standard rates (2.9% + $0.30), and verify the exact amount needed to bill clients to receive your desired payout.",
    relatedIds: ["paypal-fee-merchant-calculator", "us-import-tariff-calculator", "side-hustle-tax-calculator"]
  },
  {
    id: "paypal-fee-merchant-calculator",
    slug: "paypal-fee-merchant-calculator",
    name: "PayPal Merchant Fee Calculator",
    category: "business",
    keyword: "PayPal fee calculator",
    title: "PayPal Fee Calculator 2026 — Calculate Invoicing & Merchant Fees | TheMetricApp",
    metaDescription: "Determine exactly what PayPal charges for business merchant transactions, invoicing, and cross-border trades. See net income and reverse billing rates.",
    h1: "PayPal Seller Fee & Profit Calculator (2026)",
    description: "Quickly assess the costs of processing payments through PayPal's Business standard channel (3.49% + fixed fee or 2.9% + fixed fee) and check alternative routes.",
    relatedIds: ["stripe-fee-merchant-calculator", "vat-calculator-uk", "side-hustle-tax-calculator"]
  },
  {
    id: "vat-calculator-uk",
    slug: "vat-calculator-uk",
    name: "UK VAT Calculator",
    category: "tax",
    keyword: "VAT calculator UK",
    title: "VAT Calculator UK 2026 — Add or Remove VAT Instantly | TheMetricApp",
    metaDescription: "Add or remove UK Value Added Tax (VAT) at standard 20%, reduced 5%, or custom rates instantly. Check corporate registration limit guidelines (£90,000 threshold).",
    h1: "UK Value Added Tax (VAT) Calculator",
    description: "Whether you need to add VAT to a net quote or extract VAT from a gross purchase receipt, this tool does the reverse mathematics instantly according to HMRC standards.",
    relatedIds: ["us-import-tariff-calculator", "paypal-fee-merchant-calculator", "hourly-wage-calculator-us"]
  },
  {
    id: "self-employment-tax-calculator",
    slug: "self-employment-tax-calculator",
    name: "Self-Employment Tax Calculator",
    category: "tax",
    keyword: "self employment tax calculator 2026",
    title: "Self-Employment Tax Calculator 2026 — Free SE Tax Estimator | TheMetricApp",
    metaDescription: "Calculate your 2026 IRS self-employment tax (Schedule SE) at 15.3% on net freelance, LLC, or sole proprietor earnings. Includes standard 50% IRS deduction rules.",
    h1: "IRS Self-Employment Tax Estimator (2026)",
    description: "For sole proprietors, independent contractors, and LLC partners. Compute your standard Medicare and Social Security burden and see how much write-offs shield your final balance.",
    relatedIds: ["side-hustle-tax-calculator", "doordash-tax-estimator", "hourly-wage-calculator-us"]
  },
  {
    id: "hourly-wage-calculator-us",
    slug: "hourly-wage-calculator-us",
    name: "Hourly Wage to Annual Salary Calculator",
    category: "salary",
    keyword: "hourly to annual salary calculator",
    title: "Hourly Wage to Annual Salary Calculator 2026 — Free US Converter | TheMetricApp",
    metaDescription: "Convert your hourly wage into weekly, bi-weekly, monthly, and yearly salary brackets. Supports custom holiday pay rules and premium overtime offsets.",
    h1: "Hourly to Annual Salary & Wage Converter",
    description: "Convert a pay-rate into corresponding monthly take-home estimates and yearly projections using standard full-time hours (2,080 standard hours) or custom workweeks.",
    relatedIds: ["texas-paycheck-calculator", "doordash-tax-estimator", "self-employment-tax-calculator"]
  }
];

export const CATEGORIES = [
  { id: "all", name: "All Calculators" },
  { id: "tax", name: "Tax & Self-Employment" },
  { id: "business", name: "Business & Merchant Fees" },
  { id: "salary", name: "Salary & Paychecks" }
];
