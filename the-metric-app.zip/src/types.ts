/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CalculatorConfig {
  id: string;
  slug: string;
  name: string;
  category: "tax" | "business" | "salary" | "loans" | "investment";
  keyword: string;
  title: string;
  metaDescription: string;
  h1: string;
  description: string;
  relatedIds: string[];
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface BlogArticle {
  id: string;
  slug: string; // usually matching the calculator's slug + optional postfix or direct match
  title: string;
  metaDescription: string;
  h1: string;
  category: string;
  readTime: string;
  publishDate: string;
  author: string;
  content: string[]; // HTML/Markdown paragraphs or structured blocks
  calculatorId?: string; // Links to the matching calculator to embed it!
  relatedSlugs: string[];
  faqs: FAQItem[];
}

export interface SEOAuditResult {
  titleTag: { status: "pass" | "warn" | "fail"; label: string; value: string };
  metaDescription: { status: "pass" | "warn" | "fail"; label: string; value: string };
  h1Check: { status: "pass" | "warn" | "fail"; label: string; value: string };
  imagesAlt: { status: "pass" | "warn" | "fail"; label: string; value: string };
  jsonLdSchema: { status: "pass" | "warn" | "fail"; label: string; value: string };
  internalLinks: { status: "pass" | "warn" | "fail"; label: string; value: string };
  mobileViewport: { status: "pass" | "warn" | "fail"; label: string; value: string };
  canonicalUrl: { status: "pass" | "warn" | "fail"; label: string; value: string };
  score: number;
}
